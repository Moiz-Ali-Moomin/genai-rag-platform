project_name   = "genai-rag-prod"
aws_region     = "us-east-1"
openai_api_key = "sk-xxxxxxxxxxxxxx" # Replace in parameter store or secret manager
