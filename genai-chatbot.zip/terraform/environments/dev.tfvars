project_name   = "genai-rag-dev"
aws_region     = "us-east-1"
openai_api_key = "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"
